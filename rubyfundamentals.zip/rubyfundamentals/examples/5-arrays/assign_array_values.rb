
arr = [] 

arr[0] = [100]
arr[1] = ["one, two, three"]
arr[3] = ["a", "b", "c"]

p(arr) 


arr2 = ['r','u','v','e','n',' ','h','a','n','n','a','h']

arr2[0] = 'R'
arr2[1,3] = 'U', 'V', 'E'
arr2[5..6] = '-','H'
arr2[-4,4] = 'x','x','x','x'

p(arr2) 
