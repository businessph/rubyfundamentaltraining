puts "using a counter (range) with for loop"

for x in 1..7 do
	puts x 
end



puts "using a counter (range) with for each loop"

(1..7).each do | x |
	puts x 
end


